package dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import service.MyBatisConnector;
import vo.BoardVO;

public class BoardDAO {

	// single-ton pattern: 
	// 객체1개만생성해서 지속적으로 서비스하자
	static BoardDAO single = null;

	public static BoardDAO getInstance() {
		//생성되지 않았으면 생성
		if (single == null)
			single = new BoardDAO();
		//생성된 객체정보를 반환
		return single;
	}
	
	SqlSessionFactory factory;
	
	public BoardDAO() {
		//DAO클래스가 생성자를 통해 메모리 할당을 받을때
		//factory(어떤 DB로 접속할 것인지, mapper로 누구를 쓸것인가...)를 가져온다
		factory = MyBatisConnector.getInstance().getSessionFactory();
	}
	
	//페이징 처리를 포함한 게시물 조회
	public List<BoardVO> selectList( HashMap<String, Object> map){
		
		
		SqlSession sqlSession = factory.openSession();
		
		List<BoardVO> list =  sqlSession.selectList("b.board_list_condition", map);
		sqlSession.close();
		
		return list;
	}
	//게시글 추가 (새글)
	public int insert(BoardVO vo) {
		SqlSession sqlSession = factory.openSession(true); //auto commit
		
		//맵퍼로 전달할 파라미터는 최대 1개까지.
	int	res = sqlSession.insert("b.board_insert",vo);
	sqlSession.close();
	
	return res;
	}
	
	//게시글 상세보기
	public BoardVO selectOne(int idx) {
		SqlSession sqlSession = factory.openSession();
		BoardVO vo = sqlSession.selectOne("b.board_one", idx);
		sqlSession.close();
		
		return vo;
	}
	//조회수 증가
	public int update_readhit(int idx) {
		SqlSession sqlSession = factory.openSession(true);
		int res = sqlSession.update("b.board_update_readhit",idx);
		sqlSession.close();
		return res;
	}
	
	//댓글처리를 위해 step값 증가
	public int update_step(BoardVO baseVO) {
		
		SqlSession sqlSession = factory.openSession(true);
		int res = sqlSession.update("b.board_update_step", baseVO);
		sqlSession.close();
		return res;
		
	}
	
	//댓글추가
	public int reply(BoardVO vo) {
		SqlSession sqlSession = factory.openSession(true);
		int res = sqlSession.insert("b.board_reply", vo);
		sqlSession.close();
		return res;
	}
	
	public int update(int idx) {
		SqlSession sqlSession = factory.openSession(true);
		int res = sqlSession.update("b.del_update",idx);
		return res;
	}
	
	
	//전체 게시글 수 알아내기
	public int getRowTotal( HashMap<String, Object> map) {
		SqlSession sqlSession = factory.openSession();
		int res = sqlSession.selectOne("b.board_count", map);
		sqlSession.close();
		return res;
	}
	
	
}
